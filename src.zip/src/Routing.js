import React from 'react';
import { Switch, Route } from 'react-router-dom';
import Reports from './Reports';
import Events from './Events';

const Routing = props=>{
return (
<div>
    <Switch>
        <Route exact path='/reports' component={Reports}/>
        <Route exact path='/events' component={Events}/>
    </Switch>
    </div>
    )
}

export default Routing;