import React, { Component } from 'react';
import axios from 'axios';
import './Reports.css';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Growl } from 'primereact/growl';

class Events extends Component {
    constructor(props) {
        super(props);
        this.state = {
            eventsList: [],
            loading: false
        };
    }

    componentDidMount() {
        this.setState({ loading: true }, () => {
            axios.get("http://localhost:8080/getEventsList").then((res) => {
                console.log(res.data);
                this.setState({
                    eventsList: res.data,
                    loading: false
                });
                this.growl.show({ life: 5000, severity: 'success', summary: 'Get All Events', detail: 'Events obtained successfully' });
            }).catch(() => {
                this.setState({ loading: false });
                this.growl.show({ closable: true, sticky: true, severity: 'error', summary: 'Get All Events', detail: 'Get all events failed' });
            });
        });
    }

    render() {
        const { eventsList = [] } = this.state;
        return (
            <React.Fragment>
                <Growl ref={(el) => this.growl = el} style={{ 'marginTop': '4%' }} />
                <nav className="navbar navbar-expand-md navbar-dark fixed-top nav-bar-custom">
                    <a className="navbar-brand" href="#"><i className="fa fa-cubes nav-logo" aria-hidden="true"></i><b>Outreach </b><span className="label-FMS">FMS</span></a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarCollapse">
                        <ul className="navbar-nav mr-auto navbar-custom">
                            <li className="nav-item active">
                                <div> <i className="fa fa-th-large icon-nav" aria-hidden="true"></i> <a className="nav-link nav-link-custom" href="#">Dashboard</a></div>
                            </li>
                            <li className="nav-item active">
                                <div> <i className="fa fa-rocket icon-nav" aria-hidden="true"></i> <a className="nav-link nav-link-custom" href="#">Events</a></div>
                            </li>
                            <li className="nav-item active">
                                <div> <i className="fa fa-tachometer icon-nav" aria-hidden="true"></i> <a className="nav-link nav-link-custom" href="#">Reports</a></div>
                            </li>
                        </ul>
                        <form className="form-inline mt-4 mt-md-2">
                            <i className="fa fa-user-circle-o icon-nav-user" aria-hidden="true"></i> <span className="label-user">Murthy K</span>
                        </form>
                    </div>
                </nav>

                <main role="main" className="mainContent">
                    <div className="clear-10"></div>
                    <div className="card">
                        <div className="card-header card-header-custom-1">
                            <span className="card-title-1">ACTIONS </span>
                            <div className="div-card-icons">

                                <i className="fa fa-dot-circle-o card-icons icon-dots" aria-hidden="true"></i>
                                <i className="fa fa-refresh card-icons icon-refresh" aria-hidden="true"></i>
                                <i className="fa fa-minus-circle card-icons icon-minus" aria-hidden="true"></i>
                                <i className="fa fa-times-circle-o card-icons icon-times" aria-hidden="true"></i>

                            </div>
                        </div>
                        <div className="card-body card-body-custom ">
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="section-1">
                                        <div className="card">
                                            <div className="row no-gutters">
                                                <div className="section-header">
                                                    <i className="fa fa-envelope icon icon-section" aria-hidden="true"></i>
                                                </div>
                                                <div className="col section-body">
                                                    <div className="card-block px-2">
                                                        <b className="card-title" style={{ 'fontSize': '1.3rem' }}>Email Reminder!</b>
                                                    </div>
                                                    <div className="row">
                                                        <div className="col-md-7" style={{ 'marginLeft': '7px' }}><span className="card-text">Sit back and relax while the app send emailList!</span></div>
                                                        <div className="col-md-4"><input type="text" name="EmailID" className="form-control" placeholder="Send Email" /></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="section-2">
                                        <div className="card">
                                            <div className="row no-gutters">

                                                <div className="col section-body-2">
                                                    <div className="card-block px-2">
                                                        <b className="card-title" style={{ 'fontSize': '1.3rem', 'float': 'right' }}>Future Implementations</b>

                                                        <p className="card-text" style={{ 'float': 'right' }}>This placeholder is used for adding any other actions in future</p>

                                                    </div>
                                                </div>
                                                <div className="section-header-2">
                                                    <div>
                                                        <i className="fa fa-lightbulb-o icon-section-2" aria-hidden="true"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div className="clear-10"></div>
                    <div className="card">
                        <div className="card-header card-header-custom-1">
                            <span className="card-title-1">EVENTS</span>
                            <div className="div-card-icons">

                                <i className="fa fa-dot-circle-o card-icons icon-dots" aria-hidden="true"></i>
                                <i className="fa fa-refresh card-icons icon-refresh" aria-hidden="true"></i>
                                <i className="fa fa-minus-circle card-icons icon-minus" aria-hidden="true"></i>
                                <i className="fa fa-times-circle-o card-icons icon-times" aria-hidden="true"></i>

                            </div>
                        </div>
                        <div className="card-body card-body-custom ">
                            <div className="button-group" style={{ 'float': 'right' }}>
                                {/* <button className="btn btn-danger"><i className="fa fa-times"></i> CLEAR FILTERS</button> */}
                                <button className="btn btn-primary btn-color"><i className="fa fa-file-excel-o"></i> DOWNLOAD EXCEL</button>
                            </div>
                            <br />
                            <br />
                            <br />
                            <div className="table-responsive" style={{ 'height': '350px' }}>

                                <table className="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Action</th>
                                            <th scope="col">Event ID</th>
                                            <th scope="col">Month</th>
                                            <th scope="col">Base Location</th>
                                            <th scope="col">Council Name</th>
                                            <th scope="col">Beneficiary Name</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        {eventsList.length ? 
                                            eventsList.map(eachObj => (
                                                <React.Fragment key={'f'+eachObj.id}>
                                                <tr key={eachObj.id}>
                                                    <td><button className="btn btn-primary btn-color"><i className="fa fa-eye"></i> VIEW</button></td>
                                                    <td scope="col">{eachObj.event_id}</td>
                                                    <td scope="col">{eachObj.month}</td>
                                                    <td scope="col">{eachObj.base_location}</td>
                                                    <td scope="col">{eachObj.council_name}</td>
                                                    <td>{eachObj.beneficiary_name}</td>
                                                </tr>
                                                 <tr key={'t'+eachObj.id}>
                                                 <td></td>
                                                 <td colSpan="5">
                                                     <table className="table table-bordered">
                                                        <tbody>
                                                         <tr>
                                                             <th scope="col">Event Name</th>
                                                             <td scope="col">{eachObj.event_name}</td>
                                                         </tr>
                                                         <tr>
                                                             <th scope="col">Event Date</th>
                                                             <td scope="col">{eachObj.event_date}</td>
                                                         </tr>
                                                         <tr>
                                                             <th scope="col">Business Unit</th>
                                                             <td scope="col">{eachObj.business_unit}</td>
                                                         </tr>
                                                         <tr>
                                                             <th scope="col">Event Status</th>
                                                             <td scope="col">{eachObj.event_status}</td>
                                                         </tr>
                                                         <tr>
                                                             <th scope="col">Venue Address</th>
                                                             <td scope="col">{eachObj.venue_address}</td>
                                                         </tr>
                                                         <tr>
                                                             <th scope="col">Total Volunteers</th>
                                                             <td scope="col">{eachObj.total_volunteers}</td>
                                                         </tr>
                                                         <tr>
                                                             <th scope="col">Total Volunteer Hours</th>
                                                             <td scope="col">{eachObj.total_volunteer_hours}</td>
                                                         </tr>
                                                         <tr>
                                                             <th scope="col">Total Travel Hours</th>
                                                             <td scope="col">{eachObj.travel_hours}</td>
                                                         </tr>
                                                         </tbody>
                                                     </table>
                                                 </td>
                                             </tr>
                                             </React.Fragment>
                                            )
                                            )
                                        :null}
                                        
                                       
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </React.Fragment>
        );
    }
}

export default Events;