import React from 'react';
import Header from '../Header';

const ThanksScreen=()=>{
return(
    <>
    <Header/>


    <br></br>
               
               <div className="container">
               <div className="clear-10"></div>
                   <div className="card">
                       <div className="card-header card-header-custom-1" style={{textAlign:"center"}}>
                           <span className="card-title-1" >Many Thanks for the Feedback</span>
                           
                       </div>
                       <div className="card-body card-body-custom ">
                           <p  style={{textAlign:"center"}}>
                       Feedback like this help us constantly improve our outreach experiences by knowing what we are doing right and what we can work on. So, We appreciate you taking
        the time to send us this helpful response.

        Don't hesitate to reach out if you have any more questions, comments, or concerns.
        </p>
       
        <p  style={{textAlign:"center"}}>
        Cheers,
        <br></br>
        Outreach Team.
        </p>
                        </div>
                        </div>
                        </div>

{/*     
        <div className="row  align-items-center">
            <div className="col-6 mx-auto vertical-center-row">
                <div className="card justify-content-center">
        <h4 className="text-primary">Many Thanks for the Feedback</h4>

        Feedback like this help us constantly improve our outreach experiences by knowing what we are doing right and what we can work on. So, We appreciate you taking
        the time to send us this helpful response.

        Don't hesitate to reach out if you have any more questions, comments, or concerns.
        Cheers,
        Outreach Team.
        </div>
        </div>
        </div> */}
    

    </>
)
}

export default ThanksScreen;